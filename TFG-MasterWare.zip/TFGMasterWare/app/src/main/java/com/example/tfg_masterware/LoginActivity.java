package com.example.tfg_masterware;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ProgressBar;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class LoginActivity extends AppCompatActivity {

    //Añadir LOGIN Y REDIRIGIR A USUARIO

    TextView txtPreguntaRegistro;
    EditText email, password;
    Button login, registro;
    ImageView logoApp, fotoEmail, fotoPassword;
    Intent intent;
    Bundle bundle;


    FirebaseAuth fAuth;
    FirebaseFirestore firestoreDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        logoApp = findViewById(R.id.logoImage);
        fotoEmail = findViewById(R.id.emailLogoImage);
        email = findViewById(R.id.emailEditText);
        fotoPassword = findViewById(R.id.passwordLogoImage);
        password = findViewById(R.id.passwordEditText);
        login = findViewById(R.id.loginButton);
        txtPreguntaRegistro = findViewById(R.id.textViewNuevoUsuario);
        registro = findViewById(R.id.buttonRegistro);


        fAuth = FirebaseAuth.getInstance();
        firestoreDB = FirebaseFirestore.getInstance();

        registro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userEmail = email.getText().toString().trim();
                String userPassword = password.getText().toString().trim();

                if (!userEmail.isEmpty() && !userPassword.isEmpty()) {
                    iniciarSesion(userEmail, userPassword);
                } else {
                    Toast.makeText(LoginActivity.this, "Por favor, ingrese las credenciales.", Toast.LENGTH_SHORT).show();
                }
            }
        });



       // cargarUsuarios();

    }
    private void iniciarSesion(String email, String password) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseFirestore firestoreDB = FirebaseFirestore.getInstance();

        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Inicio de sesión exitoso
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                // Verificar el rol del usuario
                                verificarRolUsuario(user.getUid());
                            } else {
                                Toast.makeText(LoginActivity.this, "No se pudo obtener la información del usuario.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Error en el inicio de sesión
                            Toast.makeText(LoginActivity.this, "Error al iniciar sesión: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(LoginActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void verificarRolUsuario(String uid) {
        firestoreDB.collection("users").document(uid).get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                String rol = document.getString("rol");
                                redirigirPorRol(rol);
                            } else {
                                Toast.makeText(LoginActivity.this, "No se encontró información sobre el usuario.", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(LoginActivity.this, "Error al obtener datos del usuario.", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(LoginActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void redirigirPorRol(String rol) {
        Intent intent;

        if ("administrador".equals(rol)) {
            intent = new Intent(LoginActivity.this, AdminView.class);
        } else if ("preparador".equals(rol)) {
            intent = new Intent(LoginActivity.this, EmployeeView.class);
        } else {
            Toast.makeText(this, "Usuario con rol desconocido...", Toast.LENGTH_SHORT).show();
            return;
        }

        startActivity(intent);
        finish();
    }

    //metodos para añadir datos  automaticamente

   /* public void cargarUsuarios() {
        FirebaseFirestore firestoreDB = FirebaseFirestore.getInstance();

        // Lista de usuarios predefinidos
        String[][] usuarios = {
                {"Carlos Velendez", "cvelendez@gmail.com", "12485326", "propietario", },
                {"Sergio Perriquez", "sperriquez@gmail.com", "125560871", "administrador", "24681012"},
                {"Ruben Casas", "rcasas@gmail.com", "586932065", "preparador", "12472937"}
        };

        for (String[] usuario : usuarios) {
            // Crear el mapa de datos del usuario
            String claveGenerada = generarClaveAleatoria();

            Map<String, Object> userData = new HashMap<>();
            userData.put("claveAcceso", claveGenerada);//
            userData.put("nombre", usuario[0]);
            userData.put("email", usuario[1]);
            userData.put("rol", usuario[2]);
            userData.put("telefono", usuario[3]);


            // Añadir el usuario a la colección `users`
            firestoreDB.collection("users").add(userData)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            System.out.println("Usuario añadido con ID: " + documentReference.getId());
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            System.err.println("Error al añadir usuario: " + e.getMessage());
                        }
                    });
        }
    }*/
    private String generarClaveAleatoria() {
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder clave = new StringBuilder();//Clave== contraseña
        Random random = new Random();

        for (int i = 0; i < 8; i++) {
            int index = random.nextInt(caracteres.length());
            clave.append(caracteres.charAt(index));
        }

        return clave.toString();
    }



    /* public void cargarProductos() {
        FirebaseFirestore firestoreDB = FirebaseFirestore.getInstance();

        // Productos precargados
        String[][] productos = {
                {"Lácteos", "Leche", "50"},
                {"Lácteos", "Queso", "30"},
                {"Conservas", "Atún en lata", "100"},
                {"Conservas", "Tomate triturado", "80"},
                {"Snacks", "Patatas fritas", "150"},
                {"Snacks", "Frutos secos", "60"}
        };

        for (String[] producto : productos) {
            // Crear el mapa de datos
            Map<String, Object> productData = new HashMap<>();
            productData.put("categoria", producto[0]);
            productData.put("nombre", producto[1]);
            productData.put("stock", Integer.parseInt(producto[2]));

            // Añadir el producto a la colección `products`
            firestoreDB.collection("products").add(productData)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            System.out.println("Producto añadido con ID: " + documentReference.getId());
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            System.err.println("Error al añadir producto: " + e.getMessage());
                        }
                    });
        }
    }//fin del metodo de añadir productos

     */
}
