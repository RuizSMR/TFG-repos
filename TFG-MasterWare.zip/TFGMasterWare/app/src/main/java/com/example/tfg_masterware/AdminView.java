package com.example.tfg_masterware;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class AdminView extends AppCompatActivity {
    /*AÑADIR VISTAS
       LOGICA PARA VER PEDIDOS CON SU ESTADO Y OPCION PARA ASIGNAR CON SPINNER(EMPLEADO) Y BOTON(ASIGNAR)
       (POSIBLE)VENTANA PARA VER STOCK
       */

     RecyclerView recyclerView;
     PedidoAdaptador pedidoAdapter;
     List<Pedido> listaPedidos;
     FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_view);

        recyclerView = findViewById(R.id.recyclerViewPedidos);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaPedidos = new ArrayList<>();
        pedidoAdapter = new PedidoAdaptador(this, listaPedidos);
        recyclerView.setAdapter(pedidoAdapter);

        db = FirebaseFirestore.getInstance();

        cargarPedidos();
    }
    @SuppressLint("NotifyDataSetChanged")
    void cargarPedidos() {
        db.collection("orders")
                .whereEqualTo("asignadoA", null)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (querySnapshot != null) {
                            for (DocumentSnapshot document : querySnapshot) {
                                Pedido pedido = document.toObject(Pedido.class);
                                listaPedidos.add(pedido);
                            }
                            pedidoAdapter.notifyDataSetChanged();
                        }
                    } else {
                        System.err.println("Error al cargar pedidos: " + task.getException());
                    }
                });
    }
    }



    /*public void cerrarSesion() {
        fAuth.signOut();
        System.out.println("Sesión cerrada.");
    }*/
