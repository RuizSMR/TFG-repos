package com.example.tfg_masterware;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class PedidoAdaptador extends RecyclerView.Adapter<PedidoAdaptador.PedidoViewHolder> {

    private Context context;
    private List<Pedido> pedidos;

    public PedidoAdaptador(Context context, List<Pedido> pedidos) {
        this.context = context;
        this.pedidos = pedidos;
    }

    @NonNull
    @Override
    public PedidoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_pedido, parent, false);
        return new PedidoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PedidoViewHolder holder, int position) {
        Pedido pedido = pedidos.get(position);

        holder.destinoTextView.setText(pedido.getDestino());
        holder.totalProductosTextView.setText("Total de productos: " + pedido.getTotalProductos());
        holder.fechaCreacionTextView.setText("Fecha de creación: " + pedido.getFechaCreacion());

        holder.botonAsignar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String empleadoSeleccionado = holder.spinnerAsignar.getSelectedItem().toString();

                if (!empleadoSeleccionado.isEmpty()) {
                    asignarPedido(pedido.getId(), empleadoSeleccionado);
                } else {
                    Toast.makeText(context, "Por favor, seleccione un empleado.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return pedidos.size();
    }

    private void asignarPedido(String pedidoId, String empleado) {
        FirebaseFirestore firestoreDB = FirebaseFirestore.getInstance();

        firestoreDB.collection("pedidos").document(pedidoId)
                .update("asignadoA", empleado)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(context, "Pedido asignado correctamente.", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(context, "Error al asignar pedido: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    public static class PedidoViewHolder extends RecyclerView.ViewHolder {
        TextView destinoTextView, totalProductosTextView, fechaCreacionTextView;
        Spinner spinnerAsignar;
        Button botonAsignar;

        public PedidoViewHolder(@NonNull View itemView) {
            super(itemView);
            destinoTextView = itemView.findViewById(R.id.destinoTextView);
            totalProductosTextView = itemView.findViewById(R.id.totalProductosTextView);
            fechaCreacionTextView = itemView.findViewById(R.id.fechaCreacionTextView);
            spinnerAsignar = itemView.findViewById(R.id.spinnerAsignar);
            botonAsignar = itemView.findViewById(R.id.botonAsignar);
        }
    }
}
