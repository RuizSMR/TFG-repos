package com.example.tfg_masterware;

public class Pedido {
    private String id;
    private String destino;
    private int totalProductos;
    private String fechaCreacion;

    public Pedido() {
        // Constructor vacío necesario para Firebase
    }

    public Pedido(String id, String destino, int totalProductos, String fechaCreacion) {
        this.id = id;
        this.destino = destino;
        this.totalProductos = totalProductos;
        this.fechaCreacion = fechaCreacion;
    }

    public String getId() {
        return id;
    }

    public String getDestino() {
        return destino;
    }

    public int getTotalProductos() {
        return totalProductos;
    }

    public String getFechaCreacion() {
        return fechaCreacion;
    }
}

