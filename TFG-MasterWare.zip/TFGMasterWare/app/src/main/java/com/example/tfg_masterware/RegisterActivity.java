package com.example.tfg_masterware;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RegisterActivity extends AppCompatActivity {

    //CONECTAR VISTAS Y AÑADIR LOGICA DEL REGISTRO
    // VOLVER A INICIO AL RELLENAR DATOS Y AÑADIRLOS A FIRESTORE


     EditText edtNombreUsuario, edtEmailUsuario, edtPassword, edtTelefono;
     Spinner spinnerRoles;
     Button btnFinregistro;
     FirebaseAuth mAuth;
     FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Referencias a los elementos del layout
        edtNombreUsuario = findViewById(R.id.edtNombreUsuario);
        edtEmailUsuario = findViewById(R.id.edtEmailUsuario);
        edtPassword = findViewById(R.id.edtPassword);
        edtTelefono = findViewById(R.id.edtTelefono);
        spinnerRoles = findViewById(R.id.spinnerRoles);
        btnFinregistro = findViewById(R.id.btnFinregistro);
        btnFinregistro.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // Obtener los datos del formulario
                String nombre = edtNombreUsuario.getText().toString().trim();
                String email = edtEmailUsuario.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();
                String telefono = edtTelefono.getText().toString().trim();
                String rol = spinnerRoles.getSelectedItem().toString();

                // Validación básica
                if (nombre.isEmpty() || email.isEmpty() || password.isEmpty() || telefono.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "Completa todos los campos,imbecil", Toast.LENGTH_SHORT).show();
                    return;
                }

                registrarUsuario(email, password, nombre, telefono, rol);
            }
        });
    }

    private void registrarUsuario(String email, String password, String nombre, String telefono, String rol) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            Map<String, Object> usuario = new HashMap<>();
                            usuario.put("nombre", nombre);
                            usuario.put("telefono", telefono);
                            usuario.put("rol", rol);
                            usuario.put("claveAcceso", password);

                            db.collection("users")
                                    .document(user.getUid())
                                    .set(usuario, SetOptions.merge())
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            Toast.makeText(RegisterActivity.this, "Registrado exitosamente", Toast.LENGTH_SHORT).show();
                                            finish(); // Cierra la actividad después del registro
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(RegisterActivity.this, "Error al guardar los datos", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(RegisterActivity.this, "Error al registrar el usuario", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private String generarClaveAleatoria() {

        //opcion para generar clave random
        // (se puede enviar por correo al usuario)

        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder clave = new StringBuilder();//Clave== contraseña
        Random random = new Random();

        for (int i = 0; i < 8; i++) {
            int index = random.nextInt(caracteres.length());
            clave.append(caracteres.charAt(index));
        }

        return clave.toString();
    }

}


