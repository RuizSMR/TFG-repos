package com.example.tfg_masterware;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class AdaptadorProducto extends RecyclerView.Adapter<AdaptadorProducto.ProductoViewHolder> {
    private Context context;
    private List<Producto> listaProductos;

    // Constructor
    public AdaptadorProducto(Context context, List<Producto> listaProductos) {
        this.context = context;
        this.listaProductos = listaProductos;
    }

    @NonNull
    @Override
    public ProductoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Infla el diseño para cada elemento
        View view = LayoutInflater.from(context).inflate(R.layout.item_producto, parent, false);
        return new ProductoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductoViewHolder holder, int position) {
        // Obtén el producto actual
        Producto producto = listaProductos.get(position);

        // Configura las vistas del ViewHolder
        holder.textViewNombreProducto.setText(producto.getNombre());
        holder.textViewStockProducto.setText("Stock: " + producto.getStock());

        // Aquí puedes añadir la lógica para el botón (ejemplo para agregar al pedido)
        holder.nuevoPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí puedes agregar la lógica para añadir el producto al pedido
                // Por ejemplo, actualizar una lista de productos seleccionados para el pedido
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaProductos.size();
    }

    public void actualizarProductos(List<Producto> nuevosProductos) {
        // Limpia la lista actual y añade los nuevos productos
        listaProductos.clear();
        listaProductos.addAll((Collection<? extends Producto>) nuevosProductos);
        // Notifica al adaptador que los datos han cambiado
        notifyDataSetChanged();
    }

    // Clase ViewHolder interna
    public static class ProductoViewHolder extends RecyclerView.ViewHolder {
        TextView textViewNombreProducto, textViewStockProducto;
        Button nuevoPedido;

        public ProductoViewHolder(@NonNull View itemView) {
            super(itemView);

            // Vincula las vistas del diseño con los atributos del ViewHolder
            textViewNombreProducto = itemView.findViewById(R.id.textViewNombreProducto);
            textViewStockProducto = itemView.findViewById(R.id.textViewStockProducto);
            nuevoPedido = itemView.findViewById(R.id.buttonNuevoPedido);
        }
    }
}
