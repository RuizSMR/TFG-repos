package com.example.tfg_masterware;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class EmployeeView extends AppCompatActivity {

    FirebaseFirestore firestoreDB;  // Utilizamos la variable global
    RecyclerView recyclerView;
    PedidoAdaptador adapter;
    List<Map<String, Object>> listaPedidos; // Cambié el tipo de lista para que sea de Map<String, Object>

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_view);

        // Inicializamos Firestore
        firestoreDB = FirebaseFirestore.getInstance();

        // Llamamos a la función que obtiene los pedidos asignados
        obtenerPedidosAsignados("preparador"); // Aquí puedes poner el email o id del usuario que inicia sesión
    }

    public void obtenerPedidosAsignados(String usuarioAsignado) {
        // Filtrar los pedidos asignados al usuario
        firestoreDB.collection("pedidos")
                .whereEqualTo("asignadoA", usuarioAsignado)
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        List<Map<String, Object>> pedidosAsignados = new ArrayList<>();

                        for (DocumentSnapshot document : queryDocumentSnapshots) {
                            Map<String, Object> pedido = document.getData();
                            pedido.put("id", document.getId()); // Añadir ID del pedido
                            pedidosAsignados.add(pedido);
                        }

                        // Mostrar los pedidos asignados en la interfaz
                        mostrarPedidosEnLista(pedidosAsignados);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        System.err.println("Error al obtener pedidos: " + e.getMessage());
                    }
                });
    }

    void mostrarPedidosEnLista(List<Map<String, Object>> pedidosAsignados) {
        // Obtén el RecyclerView desde el layout
        recyclerView = findViewById(R.id.recyclerViewPedidos);

        // Configura el RecyclerView con un LinearLayoutManager
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Crea una instancia del adaptador personalizado
        adapter = new PedidoAdaptador(pedidosAsignados, this);

        // Asocia el adaptador al RecyclerView
        recyclerView.setAdapter(adapter);
    }
}
